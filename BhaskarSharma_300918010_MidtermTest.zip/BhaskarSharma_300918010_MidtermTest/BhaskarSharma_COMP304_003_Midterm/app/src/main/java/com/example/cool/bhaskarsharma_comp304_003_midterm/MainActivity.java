package com.example.cool.bhaskarsharma_comp304_003_midterm;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView txtHeading = (TextView) findViewById(R.id.activity1);
        txtHeading.setText(R.string.activity1);

        TextView txtSelection = (TextView) findViewById(R.id.select);
        txtSelection.setText(R.string.select);

        list = (ListView) findViewById(R.id.listView);

        String[] options = getResources().getStringArray(R.array.options);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,options);

        list.setAdapter(adapter);
    }

}
